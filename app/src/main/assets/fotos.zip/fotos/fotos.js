﻿var arr = ['IMG-20141112-WA0000.jpg',
           '8.jpg',
           '7.jpg',
           '6.jpg',
           '5.jpg',
           '4.jpg',
           '3.jpg',
           '2.jpg',
           '1.jpg'];
