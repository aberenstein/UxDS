﻿var arr = [
            ['1.html','15/10/2014','La cara visible, la menos cuidada'],
            ['2.html','20/10/2014','En el 2015 una oportunidad para otra dirigencia'],
            ['3.html','30/10/2014','¿Festejando malos acuerdos?']
          ];
